if __name__ == "__main__":
    print("Pyamda is a library... why are you trying to execute it?")
